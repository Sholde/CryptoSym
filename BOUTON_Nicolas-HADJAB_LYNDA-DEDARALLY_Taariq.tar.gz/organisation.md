# Projet Crypto

## Groupe

BOUTON Nicolas, DEDARALLY Taariq, HADJAB Lynda

## Organisation

### Code

Chacun a proposé sa version du code et on a pris la plus optimale en fonction de la rapidité, de l'espace de stockage et de la lisibilité du code.

### Contrendu

Pour le contrendu, de même, on a fais chacun les exercices et on s'est entraidé pour trouver la solution.