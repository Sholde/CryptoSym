#ifndef _attaque_geffe_h
#define _attaque_geffe_h

void attaque_geffe(char *s, int taille, int *k);

#endif 