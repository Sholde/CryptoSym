#ifndef _test_h
#define _test_h

int my_pow(int n, int e);
void int_to_char(char *s, int n, int taille);
int fonction_f(int f, int n);
void tous_les_f(void);

#endif // !_test_h